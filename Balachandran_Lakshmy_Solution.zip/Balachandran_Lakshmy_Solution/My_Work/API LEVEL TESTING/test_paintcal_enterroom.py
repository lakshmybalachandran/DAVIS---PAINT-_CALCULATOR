#API Test Module

import unittest
import requests


class Testpaintcalc(unittest.TestCase):# inheriting unittest.TestCase class


# API Test for "HOME PAGE" Availability using GET method
 def test_status_upandrun_check(self):
  base_url = "http://127.0.0.1:5000/"
  response = requests.get(base_url)
  self.assertEqual(response.status_code, 200)


#API Test for "Title Read" check
 def test_title_check(self):
  base_url = "http://127.0.0.1:5000/"
  response = requests.get(base_url)
  title = response.text
  print( title)


#API Test for "Data Entry" page
 def test_data_entry(self):
  resource_url = "http://127.0.0.1:5000/dimensions?rooms=1"
  response = requests.get(resource_url)
  self.assertEqual(response.status_code, 200)

  
  
#API Test for POST Results in Results page

 def test_results_page(self):
  resource_url = "http://127.0.0.1:5000/results"
  response = requests.post(resource_url)
  body =  {
            "length": 10,
             "width": 10,
             "height": 10
            }
  response = requests.post(resource_url,json=body)
  self.assertEqual(response.status_code, 200)

  
  

  


  

  

if __name__ == '__main__':
 unittest.main()

