package TestCases;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import Page_Objects_Paintcalc.Homescreen_paintcalc;
import Page_Objects_Paintcalc.LWHscreen_paintcalc;
import Page_Objects_Paintcalc.Resultscreen_paintcalc;

public class Result_Validation_for_Singleroom extends Baseclass {



@Test(dataProvider = "getdata")
 public void result_calc(String length, String width, String height) throws Exception {
	 
	driver = initilizeDriver();
    driver.get(prop.getProperty("Home_URL"));
	
	//objects for Page Objects
	
	Homescreen_paintcalc hm = new Homescreen_paintcalc(driver);
	LWHscreen_paintcalc lwh = new LWHscreen_paintcalc(driver);
	Resultscreen_paintcalc rs = new Resultscreen_paintcalc(driver);
	
	//Home Screen
	hm.rooms().sendKeys("1");
	hm.submitbutton().click();
	
	//LWH Data Entry Screen
	
	lwh.length().sendKeys(length);
	lwh.width().sendKeys(width);
	lwh.height().sendKeys(height);
	lwh.submitbutton().click();
	
	//Result Screen
	
	
	String Actual_URL = driver.getCurrentUrl();
	Assert.assertEquals(Actual_URL,prop.getProperty("Results_URL"));
	
	Assert.assertEquals(rs.totalarea1(),"400");
	Assert.assertEquals(rs.totalgallons1(),"1");
	
	
	
	
    driver.close();
	}



	

@DataProvider

public Object[][] getdata () {
	 
  Object[][] obj = new Object[1][3];
	
  //LWH: ALL Positive Values
	obj[0][0] = "10";
	obj[0][1] = "10";
	obj[0][2] = "10";
	
	
	return obj;
  
	 
	 }
	 


}