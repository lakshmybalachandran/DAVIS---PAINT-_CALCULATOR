package TestCases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;


import Page_Objects_Paintcalc.Homescreen_paintcalc;
import Page_Objects_Paintcalc.LWHscreen_paintcalc;
import Page_Objects_Paintcalc.Resultscreen_paintcalc;

@Test

public class Multiple_Rooms_Result_Validation extends Baseclass{

	
public void Result_Multiple_Rooms() throws IOException {
	
	
	driver = initilizeDriver();
    driver.get(prop.getProperty("Home_URL"));
	
	//objects for Page Objects
	
	Homescreen_paintcalc hm = new Homescreen_paintcalc(driver);
	LWHscreen_paintcalc lwh = new LWHscreen_paintcalc(driver);
	Resultscreen_paintcalc rs = new Resultscreen_paintcalc(driver);
	
	//Home Screen
	hm.rooms().sendKeys("2");
	hm.submitbutton().click();
	
	//LWH Data Entry Screen
	
	lwh.length().sendKeys("10");
	lwh.width().sendKeys("10");
	lwh.height().sendKeys("10");
	
	lwh.length1().sendKeys("10");
	lwh.width1().sendKeys("10");
	lwh.height1().sendKeys("5");
	
	
	
	lwh.submitbutton().click();
	
	//Result Screen
	
	
	String Actual_URL = driver.getCurrentUrl();
	Assert.assertEquals(Actual_URL,prop.getProperty("Results_URL"));
	
	Assert.assertEquals(rs.totalarea1(),"400");
	Assert.assertEquals(rs.totalgallons1(),"1");
	
	Assert.assertEquals(rs.totalarea2(),"200");
	Assert.assertEquals(rs.totalgallons2(),"1");
	
	System.out.println(driver.findElement(By.xpath(".//div[@class='container']/h5")).getText());
	
	
	
	
	
	
	
}

}