package TestCases;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Page_Objects_Paintcalc.Homescreen_paintcalc;
import Page_Objects_Paintcalc.LWHscreen_paintcalc;


public class Negative_Validation_For_Data_Page extends Baseclass {

	@Test(dataProvider = "getdata")

	
	public void result_calc(String length, String width, String height) throws Exception {
		 
		driver = initilizeDriver();
	    driver.get(prop.getProperty("Home_URL"));
		
		//objects for Page Objects
		
		Homescreen_paintcalc hm = new Homescreen_paintcalc(driver);
		LWHscreen_paintcalc lwh = new LWHscreen_paintcalc(driver);
		
		
		//Home Screen
		hm.rooms().sendKeys("1");
		hm.submitbutton().click();
		
		//LWH Data Entry Screen
		
		lwh.length().sendKeys(length);
		lwh.width().sendKeys(width);
		lwh.height().sendKeys(height);
		lwh.submitbutton().click();
		
		//Result Screen
		
		
		String Actual_URL = driver.getCurrentUrl();
		Assert.assertEquals(Actual_URL,prop.getProperty("Data_Entry_URL"));
				
	    driver.close();
		}


	@DataProvider

	public Object[][] getdata () {
		 
	  Object[][] obj = new Object[4][3];
		
	// Checking for Negative Values
	  // LHW: ALL Negative Values
	 	obj[0][0] = "-1";
	 	obj[0][1] = "-2";
	 	obj[0][2] = "-3";
	 	
	//Checking with Invalid Values
		
		obj[1][0] = "r10";
		obj[1][1] = "etd";
		obj[1][2] = "0ab";
		
		

	// Checking for NULL Values
			
		obj[2][0] = "";
		obj[2][1] = "";
		obj[2][2] = "";
		
	//Checking for Positive Floating Point Values
		
		obj[3][0] = "10.0";
		obj[3][1] = "10.0";
		obj[3][2] = "10.0";
		
		
		
		return obj;
	}
}
