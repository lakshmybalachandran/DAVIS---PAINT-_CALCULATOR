package TestCases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import Page_Objects_Paintcalc.Homescreen_paintcalc;


public class Maximum_Value_Check_Rooms extends Baseclass{

	
	
	@Test(dataProvider = "getdata")
	
public void Max_rooms(String number) throws IOException {
		
		
   driver = initilizeDriver();
   driver.get(prop.getProperty("Home_URL"));


	Homescreen_paintcalc hm = new Homescreen_paintcalc(driver);
	
	hm.rooms().sendKeys(number);
	hm.submitbutton().click();
	
	
	String Actual_URL = driver.getCurrentUrl();
	Assert.assertEquals(Actual_URL,prop.getProperty("Home_URL"));
	
	 driver.close();

}


	@DataProvider

	public Object[] getdata () {
		 
	  Object[] obj = new Object[4];
		
	  //LWH: ALL Positive Values
		obj[0] = "100000000";
		
	 //Negative Case
		obj[1] = "-1";
		
	 // Floating Point Case
		obj[2] = "1.0";
				
	// String Case 
		obj[3] = "e";
		
		
		return obj;
	  
		 
		 }
		 



}