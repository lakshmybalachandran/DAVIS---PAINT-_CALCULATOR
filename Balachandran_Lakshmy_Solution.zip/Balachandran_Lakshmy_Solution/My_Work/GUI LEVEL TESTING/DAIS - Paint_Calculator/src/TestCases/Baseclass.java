package TestCases;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Baseclass {

public WebDriver driver;
Properties prop = new Properties();




public WebDriver initilizeDriver() throws IOException {
	

 FileInputStream fis = new FileInputStream("C:\\Lakshmy_06\\eclipse-java-2018-12-R-win32-x86_64\\eclipse\\DAIS - Paint_Calculator\\src\\Page_Objects_Paintcalc\\data.properties");
 prop.load(fis);
 String browserName = prop.getProperty("browser");
 System.out.println(browserName);

if (browserName.equals("chrome"))
{
		System.setProperty("webdriver.chrome.driver","C:\\Lakshmy_06\\chromedriver_win32\\chromedriver.exe" );
		driver = new ChromeDriver();
		//execute ChromeDriver
}
	
else if (browserName.equals("firefox")) {
	
	//TO D
}
	
else if (browserName.equals("IE")) {
	
	//TO DO
}

driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
return driver;

}
}
