package Page_Objects_Paintcalc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LWHscreen_paintcalc {

	WebDriver driver;
	
	public LWHscreen_paintcalc(WebDriver driver) {
		
		this.driver = driver;
		
		
	}
	
	By length_field = By.xpath(".//input[@name='length-0']");
	By width_field = By.xpath(".//input[@name='width-0']");
	By height_field = By.xpath(".//input[@name='height-0']");
	
	By length_field1 = By.xpath(".//input[@name='length-1']");
	By width_field1 = By.xpath(".//input[@name='width-1']");
	By height_field1 = By.xpath(".//input[@name='height-1']");
	
	
	
	
	By submit_data = By.xpath(".//input[@type='submit']");

	// First Row LWH	
	
	public WebElement length() {
		
		return(driver.findElement(length_field));
	}
	
	
	
	public WebElement width() {
		
		return(driver.findElement(width_field));
	}
	
	
	public WebElement height() {
		
		return(driver.findElement(height_field));
	}
	
	
// Second Row LWH	
	public WebElement length1() {
		
		return(driver.findElement(length_field1));
	}
	
	
	
	public WebElement width1() {
		
		return(driver.findElement(width_field1));
	}
	
	
	public WebElement height1() {
		
		return(driver.findElement(height_field1));
	}
	
	public WebElement submitbutton() {
		
		return(driver.findElement(submit_data));
	}
}
