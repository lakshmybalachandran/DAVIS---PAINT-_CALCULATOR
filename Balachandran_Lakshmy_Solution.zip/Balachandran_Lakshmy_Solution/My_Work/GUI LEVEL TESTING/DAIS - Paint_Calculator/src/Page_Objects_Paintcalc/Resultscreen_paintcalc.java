package Page_Objects_Paintcalc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Resultscreen_paintcalc {
	
	WebDriver driver;
	
	public Resultscreen_paintcalc(WebDriver driver) {
		
		this.driver = driver;
		
	}

	By home_button = By.xpath(".//input[@type='submit']");
	By surface_area1= By.xpath(".//table[@name='Results']/tbody/tr[2]/td[2]"); 
    By gallons_required1 = By.xpath(".//table[@name='Results']/tbody/tr[2]/td[3]");
    By surface_area2= By.xpath(".//table[@name='Results']/tbody/tr[3]/td[2]"); 
    By gallons_required2 = By.xpath(".//table[@name='Results']/tbody/tr[3]/td[3]");
	
	
	public WebElement homebutton() {
		
		return(driver.findElement(home_button));
	
	}
	
	
     public String totalarea1() {
		
		return(driver.findElement(surface_area1).getText());
	}
	
     
     public String totalgallons1() {
 		
		return(driver.findElement(gallons_required1).getText());
	}
	
     public String totalarea2() {
 		
		return(driver.findElement(surface_area2).getText());
	}
	
     
     public String totalgallons2() {
 		
		return(driver.findElement(gallons_required2).getText());
	}
     
}
