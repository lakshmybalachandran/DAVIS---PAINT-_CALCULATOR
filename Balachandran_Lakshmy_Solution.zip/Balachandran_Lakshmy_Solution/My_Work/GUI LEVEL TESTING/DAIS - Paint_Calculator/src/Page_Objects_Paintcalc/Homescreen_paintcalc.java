package Page_Objects_Paintcalc;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Homescreen_paintcalc {
	
	WebDriver driver;
	public Homescreen_paintcalc(WebDriver driver) {
		
		this.driver = driver;
		
	}
	
	
	By rooms_field = By.xpath(".//input[@name='rooms']");
	By submit_home = By.xpath(".//input[@type='submit']");

	
	
	public WebElement rooms() {

		return(driver.findElement(rooms_field));
		
	}
	
	public WebElement submitbutton() {

		return(driver.findElement(submit_home));
		
	}
	
	public String title() {
		
		return(driver.getPageSource());
	}
	
   
}
