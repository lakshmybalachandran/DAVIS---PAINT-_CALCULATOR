Tools Needed : Selenium Webdriver 3.12 +Java 8 / TestNG 6.14/ Eclipse IDE
You can see Selenium Jars here : DAIS - Paint_Calculator\Java_FIles_For_Selenium


Run Paint_Calculator application (You can use run.py (original application) or runfixed.py (fixed by me.)

	run.py located under paint-calculator-master\ app
        runfixed.py located under Balachandran_Lakshmy_Solution\My_Work\Fixed_Paint_Calculator_Application


Open the project "DAIS - Paint_Calculator" in eclipse

       You can see selenium scrips: DAIS - Paint_Calculator\src\TestCases
       You can see Page Objects and data files for scrips: DAIS - Paint_Calculator\src\Page_Objects_Paintcalc


For running the Selenium scripts: 
    
     Go to DAIS - Paint_Calculator and click on testng.xml

